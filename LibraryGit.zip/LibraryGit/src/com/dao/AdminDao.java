package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.AdminRegister;
import com.connection.GetConnection;

public class AdminDao {
	
	GetConnection gc = new GetConnection(); 
	
	public boolean registerAdmin(AdminRegister admin)
	{
		String sql="insert into adminlogin(fname,lname,adminemail,adminpass,adminmobile)values(?,?,?,?,?) ";
		System.out.println("mani");
		// connection added..
		Connection  con =null;
		try
		{
			con = gc.getConnection() ;
			
			System.out.println("mani");
		PreparedStatement ps = con.prepareStatement(sql);
		// ps.setString(1,admin.getId());
         ps.setString(1, admin.getFirstname());
         ps.setString(2, admin.getLastname());
         ps.setString(3, admin.getAdminemail());
         ps.setString(4, admin.getAdminpass());
         ps.setString(5, admin.getAdminnumber());
        
         boolean registerFlag  = ps.executeUpdate()>0;
         con.close(); 
         return registerFlag ;  
         
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public AdminRegister loginAdmin(String adminemail, String adminpass)
	{
		AdminRegister admin=null;
		
		Connection  con =null;
		try
		{
			con = gc.getConnection() ;
			String sql="select * from adminlogin where adminemail=? and adminpass=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			 ps.setString(1, adminemail);
	         ps.setString(2, adminpass );
	         
	         ResultSet rs=ps.executeQuery();
	         
	         if(rs.next())
	         {
	        	  admin=new AdminRegister();
	        	  
	        	 admin.setId(rs.getString("id"));
	        	 admin.setAdminemail("adminemail");
	        	 admin.setAdminpass("adminpass");
	        	 
	        	 //return admin;   // return must be used as last statement, 
	        	 //it must not be thrown 
	        	 
	         } 
	         con.close();  
	         
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return admin;  
	} 
}
