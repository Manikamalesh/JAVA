package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.StudentRegister;
import com.connection.GetConnection;
  
public class StudentDao {

	GetConnection gc = new GetConnection();

	public boolean registerStudent(StudentRegister student) {
		String sql = "insert into userlogin(fname,lname,uemail,upass,umobile)values(?,?,?,?,?) ";
		System.out.println("mani");
		Connection con = null;
		int registerFlag = 0;
		try {
			con = gc.getConnection();

			System.out.println("mani");
			PreparedStatement ps = con.prepareStatement(sql);
			// ps.setString(1,admin.getId());
			ps.setString(1, student.getFirstname());
			ps.setString(2, student.getLastname());
			ps.setString(3, student.getStuemail());
			ps.setString(4, student.getStupass());
			ps.setString(5, student.getStunumber());

			System.out.println("registerStudent : StudentDao::");
			registerFlag = ps.executeUpdate();
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (registerFlag == 0)
			return false;
		else
			return true;
	}

	public boolean deleteStudent(String stuemail) {
		System.out.println("mani1");
		String sql = "delete usermanagement.userlogin where uemail=?";
		System.out.println("mani2");
		Connection con = null;
		int registerFlag = 0;
		try {
			con = gc.getConnection();

			System.out.println("mani3");
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, stuemail);
			
			registerFlag = ps.executeUpdate();
			con.close();
			
			System.out.println("deleteStudent: StudentDao::");
			System.out.println("mani4");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (registerFlag == 0){
			System.out.println("mani5");
			return false;
		}
		else
			return true;
	}

	public StudentRegister loginStudent(String stuemail, String stupass) {
		StudentRegister student = null;
		System.out.println("Sudent Dao loginStudent dao 1");
		Connection con = null;
		int registerFlag = 0;
		try {
			con = gc.getConnection();
			String sql = "select * from userlogin where uemail=? and upass=?";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, stuemail);
			ps.setString(2, stupass);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				student = new StudentRegister();

				student.setId(rs.getString("id"));
				student.setStuemail("stuemail");
				student.setStupass("stupass");
				System.out.println("Login: StudentDao::");
				System.out.println("Sudent Dao loginStudent dao 1 RS.");
			} 
			con.close();

		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		return student; 
	}
	
	// added newly
	
	  public int update(StudentRegister student){  
	      
	    	Connection con = null;
			int registerFlag = 0;
			try {
				con = gc.getConnection(); 
	             
	            PreparedStatement ps=con.prepareStatement(  
	                         "update userlogin set fname=?,lname=?, uemail=?,upass=?, umobile=?, where id=?");  
	            
	             
	            ps.setString(1,student.getFirstname());  
	            ps.setString(2,student.getLastname());  
	            ps.setString(3,student.getStuemail());   
	            ps.setString(4,student.getStunumber());
	              
	            registerFlag=ps.executeUpdate();  
	            
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return registerFlag;  
	    }   
	   
	    public  List<StudentRegister> getAllEmployees(){  
	        List<StudentRegister> list=new ArrayList<StudentRegister>();  
	          
	        Connection con = null;
			int registerFlag = 0;
			try {
				con = gc.getConnection(); 
	            PreparedStatement ps=con.prepareStatement("select * from userlogin");  
	            ResultSet rs=ps.executeQuery();  
	            while(rs.next()){  
	            	StudentRegister e=new StudentRegister();  
	                e.setId(rs.getString(1)+"");  
	                e.setFirstname(rs.getString(2));  
	                e.setLastname(rs.getString(3));  
	                e.setStuemail(rs.getString(4));  
	                e.setStupass(rs.getString(5));  
	                e.setStunumber(rs.getString(6));  
	                list.add(e);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  
	
	    public StudentRegister getStudent(String id)
	    {
	    	StudentRegister e=null;
	    	Connection con = null;
			int registerFlag = 0;
			try {
				con = gc.getConnection(); 
				System.out.println("mani1");
	            PreparedStatement ps=con.prepareStatement("select * from userlogin where id=?");  
	            ps.setString(1, id);
	            ResultSet rs=ps.executeQuery();  
	            System.out.println("mani2");
	            while(rs.next()){  
	            	 e=new StudentRegister();  
	                e.setId(rs.getString(1)+"");  
	                e.setFirstname(rs.getString(2));  
	                e.setLastname(rs.getString(3));  
	                e.setStuemail(rs.getString(4));  
	                e.setStupass(rs.getString(5));  
	                e.setStunumber(rs.getString(6));  
	                System.out.println("mani3");
	            }  
	            con.close();  
	            System.out.println("mani4");
	        }catch(Exception ae)
			{
	        	ae.printStackTrace();
			}
			return e;  
	          
	         
	    
	    	
	    }
}



