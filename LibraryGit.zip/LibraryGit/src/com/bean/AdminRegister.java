package com.bean;

public class AdminRegister {
	
	private String id;
	private String firstname;
	private String lastname;
	private String adminemail;
	private String adminpass;
	private String adminnumber;
	
	
	
	public AdminRegister() {
		super();
	}
	public AdminRegister(String firstname, String lastname, String adminemail,
			String adminpass, String adminnumber) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.adminemail = adminemail;
		this.adminpass = adminpass;
		this.adminnumber = adminnumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAdminemail() {
		return adminemail;
	}
	public void setAdminemail(String adminemail) {
		this.adminemail = adminemail;
	}
	public String getAdminpass() {
		return adminpass;
	}
	public void setAdminpass(String adminpass) {
		this.adminpass = adminpass;
	}
	public String getAdminnumber() {
		return adminnumber;
	}
	public void setAdminnumber(String adminnumber) {
		this.adminnumber = adminnumber;
	}
	
	
	@Override
	public String toString() {
		return "AdminRegister [id=" + id + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", adminemail=" + adminemail
				+ ", adminpass=" + adminpass + ", adminnumber=" + adminnumber
				+ "]";
	}
	

}
