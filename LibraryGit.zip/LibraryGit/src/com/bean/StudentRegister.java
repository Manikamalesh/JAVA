package com.bean;

public class StudentRegister {
	
	private String id;
	private String firstname;
	private String lastname;
	private String stuemail;
	private String stupass;
	private String stunumber;
	
	
	
	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getStuemail() {
		return stuemail;
	}



	public void setStuemail(String stuemail) {
		this.stuemail = stuemail;
	}



	public String getStupass() {
		return stupass;
	}



	public void setStupass(String stupass) {
		this.stupass = stupass;
	}



	public String getStunumber() {
		return stunumber;
	}



	public void setStunumber(String stunumber) {
		this.stunumber = stunumber;
	}



	public StudentRegister() {
		super();
	}



	public StudentRegister(String id, String firstname, String lastname,
			String stuemail, String stupass, String stunumber) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.stuemail = stuemail;
		this.stupass = stupass;
		this.stunumber = stunumber;
	}

}
