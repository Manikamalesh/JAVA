package com.servlet.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.StudentRegister;
import com.dao.StudentDao;

/**
 * Servlet implementation class StudentRegServlet
 */
//@WebServlet("/StudentRegServlet")
public class StudentRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=null;
		response.setContentType("text/html");
		out=response.getWriter();
		
		StudentDao dao=new StudentDao();
		
		StudentRegister student=new StudentRegister ();
		
		student.setFirstname(request.getParameter("fname"));
		student.setLastname(request.getParameter("lname"));
		student.setStuemail(request.getParameter("email"));
		student.setStupass(request.getParameter("password"));
		student.setStunumber(request.getParameter("mnumber"));
		
		if(dao.registerStudent(student))
		{
			response.sendRedirect("addusers.html");
			out.println("added successfully");
		}
		else
		{
			out.println("something is wrong");
		}
		
	}
	}

