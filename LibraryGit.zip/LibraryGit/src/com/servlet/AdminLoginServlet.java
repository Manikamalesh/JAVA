package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.AdminRegister;
import com.dao.AdminDao;

/**
 * Servlet implementation class AdminLoginServlet
 */
//@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//]  	EmployeeDao dao=new EmployeeDao();
//	   Employee employee=dao.getEmployee(request.getParameter("empid"));
//		response.sendRedirect("selectone.jsp");
		
//		admin.setAdminemail(request.getParameter("username"));
//		admin.setAdminpass(request.getParameter("password"));
		
		String email=request.getParameter("username");
		String pass=request.getParameter("password");
		
          AdminDao dao=new AdminDao();
          AdminRegister admin= dao.loginAdmin(email, pass);
          
          if(admin!=null)
          {
        	  response.sendRedirect("pageadmin.html");
          }
          else
          {
        	  response.sendRedirect("loginadmin.html");
          }
          
		
	   //	AdminRegister admin=dao.loginAdmin(request.getParameter("username,password"));
		
	
		
		
	}

}
