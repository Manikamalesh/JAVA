package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.BookRegister;
import com.bean.StudentRegister;
import com.connection.GetConnection;

public class BookDao {

	GetConnection gc = new GetConnection();

	public boolean registerBook(BookRegister book) {
		String sql = "insert into books(title,bname,authorname,genre,price,isbn)values(?,?,?,?,?,?) ";
		System.out.println("mani");
		Connection con = null;
		int registerFlag =0;
		try {
			con = gc.getConnection();

			System.out.println("mani");
			PreparedStatement ps = con.prepareStatement(sql);
			// ps.setString(1,admin.getId());
			ps.setString(1, book.getTitle());
			ps.setString(2, book.getBookname());
			ps.setString(3, book.getAuthorname());
			ps.setString(4, book.getGenre());
			ps.setString(5, book.getPrice());
			//ps.setString(5, book.getIsbn()); 
			ps.setString(6, book.getIsbn());
			
			registerFlag  = ps.executeUpdate() ;			
		    con.close();  
		      
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(registerFlag == 0)
			return false;
		else
		    return true;
		 
	} 
	public boolean deleteBook(String isbn) {
		System.out.println("mani1");
		String sql = "delete usermanagement.books where isbn=?";
		System.out.println("mani2");
		Connection con = null;
		int registerFlag = 0;
		try {
			con = gc.getConnection();

			System.out.println("mani3");
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, isbn);
			
			registerFlag = ps.executeUpdate();
			con.close();
			
			System.out.println("deleteStudent: StudentDao::");
			System.out.println("mani4");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (registerFlag == 0){
			System.out.println("mani5");
			return false;
		}
		else
			return true;
	}
	
	public  List<BookRegister> getAllBooks(){  
        List<BookRegister> list=new ArrayList<BookRegister>();  
          
        Connection con = null;
		int registerFlag = 0;
		try {
			con = gc.getConnection(); 
            PreparedStatement ps=con.prepareStatement("select * from books");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
            	BookRegister book=new BookRegister();  
            	book.setId(rs.getString(1)+"");  
            	book.setTitle(rs.getString(2)); 
            	book.setBookname(rs.getString(3));  
            	book.setAuthorname(rs.getString(4));  
            	book.setGenre(rs.getString(5));  
            	book.setPrice(rs.getString(6));  
            	book.setIsbn(rs.getString(7));  
                list.add(book);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
	
	 public BookRegister getBook(String id)
	    {
	    	BookRegister book=null;
	    	Connection con = null;
			int registerFlag = 0;
			try {
				con = gc.getConnection(); 
				System.out.println("mani1");
	            PreparedStatement ps=con.prepareStatement("select * from books where id=?");  
	            ps.setString(1, id);
	            ResultSet rs=ps.executeQuery();  
	            System.out.println("mani2");
	            while(rs.next()){  
	            	book=new BookRegister();  
	            	book.setId(rs.getString(1)+"");  
	            	book.setTitle(rs.getString(2));  
	            	book.setBookname(rs.getString(3));  
	            	book.setAuthorname(rs.getString(4));  
	            	book.setGenre(rs.getString(5));  
	            	book.setPrice(rs.getString(6));  
	            	book.setIsbn(rs.getString(7));
	                System.out.println("mani3");
	            }  
	            con.close();  
	            System.out.println("mani4");
	        }catch(Exception ae)
			{
	        	ae.printStackTrace();
			}
			return book; 
}
}