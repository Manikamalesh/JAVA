package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection 

{

	public static Connection connection;
	public static Connection getConnection()
	{
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/usermanagement?";
		String username="root";
		String password="root";
	  connection=DriverManager.getConnection(url,username,password);
	  return connection;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}
	public static void main(String args[])
	{
		getConnection();
	}
}
