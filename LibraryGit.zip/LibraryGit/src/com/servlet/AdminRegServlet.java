package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.AdminRegister;
import com.dao.AdminDao;

/**
 * Servlet implementation class AdminRegServlet
 */
//@WebServlet("/AdminRegServlet")
public class AdminRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=null;
		response.setContentType("text/html");
		out=response.getWriter();
		
		AdminDao dao=new AdminDao();
		
		AdminRegister admin=new AdminRegister();
		
		admin.setFirstname(request.getParameter("fname"));
		admin.setLastname(request.getParameter("lname"));
		admin.setAdminemail(request.getParameter("email"));
		admin.setAdminpass(request.getParameter("password"));
		admin.setAdminnumber(request.getParameter("mob"));
		
		if(dao.registerAdmin(admin))
		{
			response.sendRedirect("loginadmin.html");
		}
		else
		{
			out.println("something is wrong");
		}
		
	}

}
